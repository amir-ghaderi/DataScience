from flask import Flask, render_template, jsonify, request
from waitress import serve

app = Flask(__name__)

#Developer/Debug Mode
#set FLASK_ENV=development
#flask run

@app.route('/')
def index():
    return render_template("index.html")
    

if __name__ == "__main__":
    #app.run()
    serve(app, host='0.0.0.0')






















